import { Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';

function App() {
  // Datos de ejemplo para las gemas
  const gemstones = [
    { id: 1, name: 'Ruby', stock: 12 },
    { id: 2, name: 'Esmeralda', stock: 8 },
    { id: 3, name: 'Sapphire', stock: 23 },
    { id: 4, name: 'Amatista', stock: 4 },
    { id: 5, name: 'Diamante', stock: 30 },
  ];

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route
        path="/dashboard"
        element={
          <div className="flex bg-background min-h-screen text-text">
            <Sidebar />
            <Dashboard gemstones={gemstones} />
          </div>
        }
      />
    </Routes>
  );
}

export default App;
