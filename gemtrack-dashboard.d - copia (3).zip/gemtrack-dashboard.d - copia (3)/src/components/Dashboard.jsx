import { useState, useMemo } from "react";
import { Search, X } from "lucide-react";
import Fuse from "fuse.js";

function Dashboard({ gemstones = [] }) {
  const [search, setSearch] = useState("");

  // Configuración de Fuse.js para búsqueda por nombre de piedra
  const fuse = useMemo(() => {
    const options = {
      keys: ["name"],
      threshold: 0.3, // ajusta sensibilidad de búsqueda
    };
    return new Fuse(gemstones, options);
  }, [gemstones]);

  // Resultados filtrados según el término de búsqueda
  const filteredGemstones = useMemo(() => {
    if (!search) return gemstones;
    return fuse.search(search).map(result => result.item);
  }, [search, fuse, gemstones]);

  return (
    <div className="flex-1 p-8">
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-accent">Dashboard</h2>
        <p className="text-muted mt-1">Welcome to our BioCristal inventory.</p>

        {/* Barra de búsqueda con icono y botón limpiar */}
        <div className="relative mt-4 mb-6 w-full md:w-1/2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={20} />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search gemstones..."
            className="w-full pl-10 pr-10 py-2 rounded-2xl bg-background border border-border text-accent placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-accent transition"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Estadísticas generales */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
        <div className="bg-card p-6 rounded-2xl shadow-lg">
          <p className="text-muted mb-1">Total Gemstones</p>
          <p className="text-2xl font-semibold text-accent">{gemstones.length}</p>
        </div>
        <div className="bg-card p-6 rounded-2xl shadow-lg">
          <p className="text-muted mb-1">Available Stock</p>
          <p className="text-2xl font-semibold text-accent">
            {gemstones.reduce((sum, g) => sum + (g.stock || 0), 0)}
          </p>
        </div>
        <div className="bg-card p-6 rounded-2xl shadow-lg">
          <p className="text-muted mb-1">Low Stock</p>
          <p className="text-2xl font-semibold text-accent">
            {gemstones.filter(g => g.stock && g.stock < 10).length}
          </p>
        </div>
        <div className="bg-card p-6 rounded-2xl shadow-lg">
          <p className="text-muted mb-1">Pending Orders</p>
          <p className="text-2xl font-semibold text-accent">803</p>
        </div>
      </div>

      {/* Lista de piedras filtradas */}
      <div className="mt-8">
        <h3 className="text-xl font-semibold text-accent mb-4">Gemstone List</h3>
        <ul className="space-y-2">
          {filteredGemstones.map((gem) => (
            <li key={gem.id} className="bg-card p-4 rounded-2xl">
              <p className="text-accent font-medium">{gem.name}</p>
              <p className="text-muted text-sm">Stock: {gem.stock}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Dashboard;
