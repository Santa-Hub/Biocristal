import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (username === 'sneider' && password === '1020111282') {
      navigate('/dashboard');
    } else {
      setError('Usuario o contraseña incorrectos');
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center text-text">
      <form
        onSubmit={handleSubmit}
        className="bg-card p-8 rounded-2xl shadow-md w-96"
      >
        <h2 className="text-3xl font-bold mb-6 text-center text-accent">Iniciar Sesión</h2>

        {error && <p className="text-red-500 mb-4">{error}</p>}

        <div className="mb-4">
          <label className="block mb-1">Usuario</label>
          <input
            type="text"
            className="w-full p-2 rounded bg-background border border-muted"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Ingresa tu usuario"
          />
        </div>

        <div className="mb-6">
          <label className="block mb-1">Contraseña</label>
          <input
            type="password"
            className="w-full p-2 rounded bg-background border border-muted"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Ingresa tu contraseña"
          />
        </div>

        <button
          type="submit"
          className="w-full bg-accent text-white p-2 rounded hover:bg-opacity-90 transition"
        >
          Entrar
        </button>
      </form>
    </div>
  );
}

export default Login;
