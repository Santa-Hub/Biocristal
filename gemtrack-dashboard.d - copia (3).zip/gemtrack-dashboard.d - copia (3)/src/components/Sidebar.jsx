function Sidebar() {
  return (
    <div className="w-64 bg-card p-4 text-text shadow-lg rounded-r-2xl">
      <span className="text-2xl font-bold text-accent">BioCristal 💎</span>

      <ul className="space-y-4">
        <li className="hover:text-accent cursor-pointer">Dashboard</li>
        <li className="hover:text-accent cursor-pointer">Gemstones</li>
        <li className="hover:text-accent cursor-pointer">Categories</li>
        <li className="hover:text-accent cursor-pointer">Sales</li>
        <li className="hover:text-accent cursor-pointer">Customers</li>
      </ul>
    </div>
  );
}

export default Sidebar;